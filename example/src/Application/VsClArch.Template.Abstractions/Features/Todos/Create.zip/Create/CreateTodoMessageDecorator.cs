using System;
using BKT.Utilities.Application.Abstractions;
using BKT.Utilities.Application.Decorators;
using BKT.Utilities.Core.Results;
using Microsoft.Extensions.Logging;
using VsClArch.Template.Application.Mediator;

namespace VsClArch.Template.Application.Todos.Create;

/// <summary>
/// A decorator for <see cref="IFeatureHandler{TFeature}"/> of type <see cref="CreateTodoInput"/> that adds logging.
/// </summary>
internal sealed class CreateTodoMessageDecorator : IPipelineBehavior<CreateTodoInput>
{
    // private readonly IFeatureHandler<CreateTodoInput> _innerHandler;
    private readonly ILogger<CreateTodoMessageDecorator> _logger;

    /// <summary>
    /// Initializes a new instance of the <see cref="CreateTodoMessageDecorator"/> class.
    /// </summary>
    /// <param name="innerHandler">The inner feature handler to decorate.</param>
    /// <param name="logger">The logger.</param>
    public CreateTodoMessageDecorator(IFeatureHandler<CreateTodoInput> innerHandler, ILogger<CreateTodoMessageDecorator> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        // _innerHandler = innerHandler ?? throw new ArgumentNullException(nameof(innerHandler));
    }

    /// <inheritdoc />
    // public async Task<Result> Handle(CreateTodoInput command, CancellationToken cancellationToken)
    // {
    //     _logger.LogInformation("Before executing CreateTodoHandler...");
    //     Result result = await _innerHandler.Handle(command, cancellationToken);

    //     _logger.LogInformation("After executing CreateTodoHandler...");

    //     return result;
    // }

    public async Task<Result> Handle(CreateTodoInput message, MessageHandlerDelegate<CreateTodoInput, Result> next, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Before executing CreateTodoHandler...");

        Result result = await next(message, cancellationToken);

        _logger.LogInformation("After executing CreateTodoHandler...");
        return result;
    }
}
