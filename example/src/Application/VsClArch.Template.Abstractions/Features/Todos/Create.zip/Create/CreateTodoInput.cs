using System;
using BKT.Utilities.Application.Abstractions;

namespace VsClArch.Template.Application.Todos.Create;

/// <summary>
/// Represents the input for creating a new Todo item.
/// </summary>
/// <param name="UserId"></param>
/// <param name="Description">The description of the Todo item.</param>
/// <param name="Labels">A list of labels for the Todo item.</param>
/// <param name="IsCompleted">A value indicating whether the Todo item is completed.</param>
/// <param name="DueDate">The optional due date for the Todo item.</param>
public sealed record CreateTodoInput(
    Guid UserId,
    string Description,
    List<string> Labels,
    bool IsCompleted,
    DateTime? DueDate
) : IFeature;
